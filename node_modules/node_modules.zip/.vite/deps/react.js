import {
  require_react
} from "./chunk-VHW23IB5.js";
export default require_react();
