import {
  require_react_dom
} from "./chunk-TR7CFUFP.js";
import "./chunk-VHW23IB5.js";
export default require_react_dom();
